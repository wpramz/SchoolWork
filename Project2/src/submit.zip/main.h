/*
 * main.h
 *
 *  Created on: Mar 17, 2019
 *      Author: willi
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "binarySearchTree.h"
#include "AVLTree.h"
#include "node.h"
#include "splayTree.h"

#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>




#endif /* MAIN_H_ */
