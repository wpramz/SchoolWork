/*
 * main.h
 *
 *  Created on: Jan 14, 2019
 *      Author: willi
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
#include "list.h"
using namespace std;



#endif /* MAIN_H_ */
