/*
 * main.h
 *
 *  Created on: Apr 18, 2019
 *      Author: willi
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "node.h"
#include "chainHash.h"
#include "quadHash.h"
#include <ctime>
#include <algorithm>
#include <string>




#endif /* MAIN_H_ */
